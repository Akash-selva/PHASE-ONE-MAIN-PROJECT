package Phase1;

public class MainProg {

	public static void main(String[] args) {
		
		
		FileOperations.createMainFolderIfNotPresent("main project");
		
		MenuOptions.printWelcomeScreen("LockedMe", "Akash");
		
		HandleOptions.handleWelcomeScreenInput();
	}

	
}